# Iceify Logger

**I Am not responsible for any malicious use of this program**


Iceify Logger, The most Over-powered cookie logger in github 🤯 
# Discord Server

https://discord.gg/VvH5PvbVCU (UPDATED INV)

# Tutorial
https://www.youtube.com/watch?v=3AcHtJxKao4

# Feautres
	🟢Grabs Cookie from (Edge,opera,chrome,etc.)
	🟢Sends Robux Balance to webhook
	🟢Sends Premium Status to webhook
	🟢Sends Roblox Username to webhook
	🟢Sends IP Address to webhook
	🟢Sends RAP to webhook
	🟢Sends Creation date to webhook
	🟢Sends Account age to webhook
	🟣NOT DETECTED BY WINDOWS DEFENDER AND SOME OTHER ANTI VIRUSES
# To Do
	💎Add Token Grabber
	💎Add EXE version Builder
	💎Add Password Stealer
